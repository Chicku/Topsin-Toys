﻿using System;

namespace Tailspin.Infrastructure
{
    public interface IEntity
    {
        object Key { get; }
    }
}
