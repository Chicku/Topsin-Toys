﻿CREATE ROLE [aspnet_Profile_FullAccess]
    AUTHORIZATION [dbo];

