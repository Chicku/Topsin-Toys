﻿CREATE ROLE [aspnet_Roles_ReportingAccess]
    AUTHORIZATION [dbo];

