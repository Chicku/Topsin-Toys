﻿CREATE ROLE [aspnet_Personalization_FullAccess]
    AUTHORIZATION [dbo];

