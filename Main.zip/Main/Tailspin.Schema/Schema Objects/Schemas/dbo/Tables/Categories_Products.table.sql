﻿CREATE TABLE [dbo].[Categories_Products] (
    [CategoryCode]  NVARCHAR (63) NOT NULL,
    [SKU]        	NVARCHAR (50) NOT NULL
);

