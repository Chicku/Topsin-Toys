﻿CREATE TABLE [dbo].[Products_Options] (
    [SKU]           NVARCHAR (50) NOT NULL,
    [OptionID]      INT           NOT NULL,
    [OptionValueID] INT           NOT NULL
);

