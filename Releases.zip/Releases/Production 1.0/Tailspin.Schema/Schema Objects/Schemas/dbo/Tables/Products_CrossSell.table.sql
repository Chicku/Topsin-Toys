﻿CREATE TABLE [dbo].[Products_CrossSell] (
    [SKU]      NVARCHAR (50) NOT NULL,
    [CrossSKU] NVARCHAR (50) NOT NULL
);

