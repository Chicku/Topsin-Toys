﻿CREATE ROLE [aspnet_Roles_BasicAccess]
    AUTHORIZATION [dbo];

