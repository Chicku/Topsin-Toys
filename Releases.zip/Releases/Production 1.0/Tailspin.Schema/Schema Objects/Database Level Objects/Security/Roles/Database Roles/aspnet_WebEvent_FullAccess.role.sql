﻿CREATE ROLE [aspnet_WebEvent_FullAccess]
    AUTHORIZATION [dbo];

