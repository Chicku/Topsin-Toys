﻿CREATE ROLE [aspnet_Membership_ReportingAccess]
    AUTHORIZATION [dbo];

