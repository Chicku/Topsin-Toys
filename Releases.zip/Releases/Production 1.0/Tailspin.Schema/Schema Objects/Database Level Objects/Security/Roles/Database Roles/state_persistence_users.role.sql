﻿CREATE ROLE [state_persistence_users]
    AUTHORIZATION [dbo];

