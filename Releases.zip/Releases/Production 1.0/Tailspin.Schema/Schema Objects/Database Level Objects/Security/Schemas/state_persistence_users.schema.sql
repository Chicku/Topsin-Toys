﻿CREATE SCHEMA [state_persistence_users]
    AUTHORIZATION [state_persistence_users];

