﻿CREATE TABLE [dbo].[Categories] (
    [Code]             NVARCHAR (63)    NOT NULL,
    [Title] 		   NVARCHAR (255)   NOT NULL
);

