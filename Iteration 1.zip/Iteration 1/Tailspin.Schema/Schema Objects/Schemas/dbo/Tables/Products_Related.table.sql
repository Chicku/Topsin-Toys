﻿CREATE TABLE [dbo].[Products_Related] (
    [SKU]        NVARCHAR (50) NOT NULL,
    [RelatedSKU] NVARCHAR (50) NOT NULL
);

