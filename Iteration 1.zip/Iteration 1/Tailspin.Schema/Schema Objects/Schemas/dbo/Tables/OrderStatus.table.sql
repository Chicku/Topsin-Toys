﻿CREATE TABLE [dbo].[OrderStatus] (
    [OrderStatusID] INT           NOT NULL,
    [Description]   NVARCHAR (50) NULL
);

