﻿CREATE ROLE [aspnet_Personalization_BasicAccess]
    AUTHORIZATION [dbo];

