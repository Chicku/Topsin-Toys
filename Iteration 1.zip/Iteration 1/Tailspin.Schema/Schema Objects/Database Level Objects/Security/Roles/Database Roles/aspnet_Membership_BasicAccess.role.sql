﻿CREATE ROLE [aspnet_Membership_BasicAccess]
    AUTHORIZATION [dbo];

