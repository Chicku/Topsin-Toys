﻿CREATE ROLE [aspnet_Personalization_ReportingAccess]
    AUTHORIZATION [dbo];

