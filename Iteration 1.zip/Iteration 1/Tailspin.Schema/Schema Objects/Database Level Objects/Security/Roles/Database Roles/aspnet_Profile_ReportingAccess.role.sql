﻿CREATE ROLE [aspnet_Profile_ReportingAccess]
    AUTHORIZATION [dbo];

